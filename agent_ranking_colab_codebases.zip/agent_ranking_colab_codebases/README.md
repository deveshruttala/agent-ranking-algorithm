
# AURA-Rank Colab Codebases

This package contains two different Python/Google Colab codebases for your MCP / Agent Hub ranking system.

## 1. Research codebase

File:

```text
research_agent_skill_rank.py
research_agent_skill_rank.ipynb
```

Use this when you want to test the algorithm like a research experiment.

It includes:

- Weighted PageRank-style `AgentRank`
- Task-specific `SkillRank`
- Final `AURA-Rank` agent selection score
- Memory scoring with scoped memory
- Permission/auth/cost/latency/risk-aware ranking
- Evaluation metrics: Hit@K, MRR, NDCG@K
- A2A chain planner with ChainRank
- Plots and explainable ranking tables

## 2. Real usecase codebase

File:

```text
real_usecase_mcp_router.py
real_usecase_mcp_router.ipynb
```

Use this as the backend logic prototype for your SaaS MCP Gateway.

It includes:

- Client token permissions
- Connections/auth readiness
- Memory store with policy checks
- Tool specs and agent specs
- AURA ranking service
- Permission approval checks
- Mock agent executor
- Agent router that supports direct routing and multi-agent chain routing
- Execution logs with token/cost/latency estimates

## Algorithm summary

The final rank is:

```text
AURA(agent, task, user, client) =
  0.25 semantic_task_match
+ 0.18 capability_match
+ 0.12 AgentRank
+ 0.10 user_history_success
+ 0.08 workspace_history_success
+ 0.08 auth_readiness
+ 0.07 permission_fit
+ 0.06 latency_score
+ 0.06 cost_score
+ 0.05 memory_fit
+ 0.05 trust_score
- 0.15 risk_penalty
- 0.10 missing_scope_penalty
```

`AgentRank` is a weighted PageRank-like graph authority algorithm over agents, skills, tools, workflows, and successful handoffs.

## How to use in Google Colab

1. Upload either `.py` file to Colab.
2. Run:

```python
%run research_agent_skill_rank.py
```

or:

```python
%run real_usecase_mcp_router.py
```

You can also open the `.ipynb` files directly in Colab.
